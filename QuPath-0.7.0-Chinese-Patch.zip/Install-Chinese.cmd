@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Chinese.ps1" %*
set "PATCH_EXIT_CODE=%ERRORLEVEL%"
echo.
pause
exit /b %PATCH_EXIT_CODE%
