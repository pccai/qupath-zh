"""Repackage an official jdk.localedata.jmod; Python 3 standard library only.

Usage: python rebuild_localedata.py path/to/jdk.localedata.jmod output-directory
The original jmod is available in the official Temurin jmods archive in source.json.
"""
import argparse
import hashlib
from pathlib import Path
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("jmod", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
if hashlib.sha256(args.jmod.read_bytes()).hexdigest() != "4c409d8ec974e0fe862ac05c15bc826d245ab043f79f63050a621fd9d6b718a2":
    parser.error("Input jmod does not match the official Temurin 25.0.2+10 module")
args.output.mkdir(parents=True, exist_ok=True)
with zipfile.ZipFile(args.jmod) as jmod, zipfile.ZipFile(args.output / "jdk.localedata.jar", "w", zipfile.ZIP_DEFLATED) as jar:
    for entry in jmod.infolist():
        if entry.is_dir():
            continue
        if entry.filename.startswith("classes/"):
            jar.writestr(entry.filename[len("classes/"):], jmod.read(entry))
        elif entry.filename.startswith("legal/"):
            target = args.output / "licenses" / entry.filename[len("legal/"):]
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(jmod.read(entry))
print("Created jdk.localedata.jar; keep licenses outside the module jar.")
print("Module content must remain unchanged to pass the runtime's module hash check.")
