QuPath 0.7.0 Chinese UI supplement, 2026-10-18

The overlay changes presentation code only. It does not modify the original
application JARs. The target library SHA256 values are pinned in manifest.json.

Editable runtime translations:
  payload/app/localization/qupath-supplemental_zh.properties
  payload/app/localization/qupath/{ext,fx}/.../*_zh.properties

Developer sources:
  ui-src/ChineseUI.java         UTF-8 resource lookup and UI display helpers
  ui-src/PatchUI.java           offline ASM transformer
  ui-translations.json         English-to-Chinese source catalog
  ui-rules.tsv                 exact reviewed class/method/literal sites
  ui-overlay-classes.tsv       original JAR and class names in the overlay
  upstream-source/             corresponding original versioned Java sources

Rules columns: JVM class name, method name, ldc/concat, base64 UTF-8 literal.
The transformer also contains narrowly scoped display adapters for class labels,
the class and measurement filters, measurement cells, object labels, legacy menu
paths, and component resource lookups. Dynamic concat arguments are preserved.
The ClassVisibilityConverter string switch is normalized on input; its original
hashes are preserved. Per-package implementation versions are also preserved.

Rebuilding requires Python 3, a JDK 17+ (java and javac on PATH), the ORIGINAL
QuPath 0.7.0 app directory, and ASM 9.9:
https://repo.maven.apache.org/maven2/org/ow2/asm/asm/9.9/asm-9.9.jar

python tools/build_ui.py --app "D:/Apps/QuPath-0.7.0/app" --asm "D:/Build/asm-9.9.jar"

The build updates the overlay, supplemental properties, payload hashes, and class
list in manifest.json. ASM is a build-time dependency, not needed by recipients.
The original classes are Java 25; the transformer/helper themselves target Java 17.

Upstream sources:
- QuPath v0.7.0: https://github.com/qupath/qupath/tree/v0.7.0
  GPL-3.0-or-later; original edited classes under upstream-source/qupath-v0.7.0.
- DJL extension 0.4.2, training extension 0.1.0, fxtras 0.3.0, extensionmanager 1.1.1:
  Apache-2.0; complete published source JAR contents under upstream-source.
  Published source artifacts were retrieved from:
  https://maven.scijava.org/content/repositories/releases/io/github/qupath/

Modification notice: the distributed overlay classes are modified versions.
The modifications are exactly described by ui-rules.tsv and ui-src/PatchUI.java.
The upstream authors did not publish or endorse this Chinese supplement.
The new helper, builder and their catalogs are GPL-3.0-or-later.
See ../licenses/QuPath-GPL-3.0.txt and the Apache license notices.
