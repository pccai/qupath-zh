"""Rebuild the QuPath 0.7.0 Chinese UI overlay; requires JDK 17+ and ASM 9.9.

python tools/build_ui.py --app C:/path/to/QuPath-0.7.0/app --asm C:/path/to/asm-9.9.jar
The original application JARs are read only. All edited text sites are in ui-rules.tsv.
"""
import argparse
import hashlib
import json
import pathlib
import re
import subprocess
import tempfile

ROOT = pathlib.Path(__file__).resolve().parent.parent

def prop(value):
    return (value.replace('\\', '\\\\').replace('\r', '\\r').replace('\n', '\\n')
            .replace('\t', '\\t').replace('\x01', '\\u0001').replace('\x02', '\\u0002'))

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--app', required=True, type=pathlib.Path)
    parser.add_argument('--asm', required=True, type=pathlib.Path)
    args = parser.parse_args()
    manifest_path = ROOT/'manifest.json'
    manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
    for entry in manifest['requiredJars']:
        assert hashlib.sha256((args.app/entry['name']).read_bytes()).hexdigest() == entry['sha256'], 'Original JAR differs: '+entry['name']
    translations = json.loads((ROOT/'tools/ui-translations.json').read_text(encoding='utf-8'))
    en, zh, keys = [], [], set()
    for original, translated in translations.items():
        slug = re.sub('[^a-z0-9]+', '_', original.lower()).strip('_')[:90]
        key = 'ui.' + slug
        if key in keys:
            key += '_' + hashlib.sha256(original.encode()).hexdigest()[:8]
        keys.add(key)
        assert original.count('\x01') == translated.count('\x01'), original
        en.append(f'{key} = {prop(original)}')
        zh.extend([f'# {prop(original)}', f'{key} = {prop(translated)}'])
    loc = ROOT/'payload/app/localization'
    loc.mkdir(parents=True, exist_ok=True)
    (loc/'qupath-supplemental.properties').write_text('\n'.join(en)+'\n', encoding='utf-8')
    (loc/'qupath-supplemental_zh.properties').write_text('\n'.join(zh)+'\n', encoding='utf-8')
    with tempfile.TemporaryDirectory(prefix='qupath-zh-build-') as temp:
        work = pathlib.Path(temp)
        helper = work/'helper'; helper.mkdir()
        builder = work/'builder'; builder.mkdir()
        subprocess.run(['javac', '--release', '17', '-encoding', 'UTF-8', '-d', str(helper), str(ROOT/'tools/ui-src/ChineseUI.java')], check=True)
        subprocess.run(['javac', '--release', '17', '-encoding', 'UTF-8', '-cp', str(args.asm), '-d', str(builder), str(ROOT/'tools/ui-src/PatchUI.java')], check=True)
        output = ROOT/'payload/app/qupath-chinese-ui-0.7.0.jar'
        subprocess.run(['java', '-cp', str(builder)+';'+str(args.asm), 'PatchUI', str(args.app), str(ROOT/'tools/ui-rules.tsv'), str(output), str(helper)], check=True)
        pathlib.Path(str(output)+'.classes.tsv').replace(ROOT/'tools/ui-overlay-classes.tsv')
    print(f'Supplemental entries: {len(translations)}')
    manifest['files'] = [{'path':f.relative_to(ROOT).as_posix(), 'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
                         for f in sorted((ROOT/'payload').rglob('*')) if f.is_file()]
    manifest['overlayClasses'] = [line.split('\t')[1].replace('/', '.') for line in (ROOT/'tools/ui-overlay-classes.tsv').read_text().splitlines()]
    manifest['coverage']['supplementalKeys'] = len(translations)
    manifest['coverage']['reviewedTextSites'] = len((ROOT/'tools/ui-rules.tsv').read_text().splitlines())
    manifest['coverage']['overlaidClasses'] = len(manifest['overlayClasses'])
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')

if __name__ == '__main__':
    main()
