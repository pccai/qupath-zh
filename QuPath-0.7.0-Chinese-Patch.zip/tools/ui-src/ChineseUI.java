/* Supplemental UI localization for QuPath 0.7.0. GPL-3.0-or-later. */
package qupath.zh;

import java.io.*;
import java.lang.invoke.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Text presentation only: this class never changes image, project or class data. */
public final class ChineseUI {
    private static final String BASE = "qupath-supplemental";
    private static final Map<String,String> KEYS = new HashMap<>();
    static {
        var base = ResourceBundle.getBundle(BASE, Locale.ROOT, ChineseUI.class.getClassLoader());
        for (String key : base.keySet()) KEYS.put(base.getString(key), key);
    }
    private ChineseUI() {}
    public static ResourceBundle bundle(String name) {
        return ResourceBundle.getBundle(name, Locale.getDefault(Locale.Category.DISPLAY), ChineseUI.class.getClassLoader());
    }
    public static String text(String original) {
        if (original == null || !Locale.getDefault(Locale.Category.DISPLAY).getLanguage().equals("zh")) return original;
        String key = KEYS.get(original);
        return key == null ? original : bundle(BASE).getString(key);
    }
    public static String english(String displayed) {
        if (displayed == null) return null;
        var resource = bundle(BASE);
        for (var entry : KEYS.entrySet()) if (resource.getString(entry.getValue()).equals(displayed)) return entry.getKey();
        return displayed;
    }
    /** Normalize legacy extension paths to QuPath resource keys, so menus are reused. */
    public static String menuPath(String path) {
        if (path == null) return null;
        String[] parts = path.split(">", -1);
        for (int i = 0; i < parts.length; i++) {
            String part = parts[i].trim();
            if (i == 0 && Set.of("File","Edit","Tools","View","Objects","Analyze","Automate","Measure","TMA","Extensions","Help").contains(part))
                parts[i] = "Menu." + part;
            else parts[i] = text(part);
        }
        return String.join(">", parts);
    }
    /** Called only by the class-list cell renderer, never by PathClass itself. */
    public static String classLabel(String label) {
        if (label == null) return null;
        String suffix = "";
        int count = label.lastIndexOf(" (");
        if (count > 0 && label.substring(count).matches(" \\(\\d+\\)")) {
            suffix = label.substring(count); label = label.substring(0, count);
        }
        // Only the built-in class labels are mapped; custom classes pass through.
        if (Set.of("None","Tumor","Stroma","Immune cells","Necrosis","Other","Region*","Ignore*","Positive","Negative").contains(label))
            return text(label) + suffix;
        return label + suffix;
    }
    public static java.util.function.Function<Object,String> classFilterFunction() {
        return object -> classLabel(Objects.toString(object));
    }
    public static java.util.function.Function<Object,String> measurementFilterFunction() {
        return object -> text(Objects.toString(object));
    }
    /** The raw value is still used for icons, model queries, clipboard and serialization. */
    public static String measurementValue(String value, String key) {
        if ("Classification".equals(key)) return classLabel(value);
        if ("Object type".equals(key)) return text(value);
        return value;
    }
    /** Default object labels only. Explicit names and custom label extractors are preserved. */
    public static String objectLabel(Object object) {
        if (object == null) return "";
        String raw = object.toString();
        try {
            if (object.getClass().getMethod("getName").invoke(object) != null) return raw;
        } catch (ReflectiveOperationException e) { return raw; }
        for (String type : List.of("Annotation", "Detection", "Cell", "Tile", "TMA core")) {
            if (raw.equals(type)) return text(type);
            if (raw.startsWith(type + " (")) {
                int end = raw.indexOf(')', type.length() + 2);
                if (end > 0) return text(type) + " (" + classLabel(raw.substring(type.length() + 2, end)) + ")" + raw.substring(end + 1);
            }
        }
        return text(raw);
    }
    /** Preserve all dynamic arguments while translating a reviewed concatenation recipe. */
    public static CallSite concat(MethodHandles.Lookup lookup, String name, MethodType type,
                                  String recipe, Object... constants) throws StringConcatException {
        return StringConcatFactory.makeConcatWithConstants(lookup, name, type, text(recipe), constants);
    }
}
