/* Offline overlay builder. GPL-3.0-or-later. Requires ASM 9.9 and the original QuPath JARs. */
import org.objectweb.asm.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;

public final class PatchUI {
    private static final String HELPER = "qupath/zh/ChineseUI";
    private static final String STRING = "(Ljava/lang/String;)Ljava/lang/String;";
    public static void main(String[] args) throws Exception {
        Path app = Path.of(args[0]), rulesFile = Path.of(args[1]), output = Path.of(args[2]);
        Set<String> rules = new HashSet<>(Files.readAllLines(rulesFile, StandardCharsets.UTF_8));
        Set<String> used = new HashSet<>();
        List<String> changes = new ArrayList<>();
        Map<String,byte[]> entries = new LinkedHashMap<>();
        Manifest manifest = new Manifest();
        manifest.getMainAttributes().putValue("Manifest-Version", "1.0");
        manifest.getMainAttributes().putValue("Implementation-Title", "QuPath 0.7.0 supplemental Chinese UI");
        {
            for (Path jarPath : Files.list(app).filter(p -> p.toString().endsWith(".jar")).sorted().toList()) {
                String jarName = jarPath.getFileName().toString();
                if (!(jarName.startsWith("qupath-") || jarName.startsWith("extensionmanager-"))) continue;
                if (jarName.startsWith("qupath-chinese-ui-")) continue;
                try (var jar = new JarFile(jarPath.toFile())) {
                    for (var entry : Collections.list(jar.entries())) {
                        if (!entry.getName().endsWith(".class")) continue;
                        byte[] original = jar.getInputStream(entry).readAllBytes();
                        var reader = new ClassReader(original);
                        String cls = reader.getClassName();
                        boolean[] changed = {false};
                        var writer = new ClassWriter(reader, ClassWriter.COMPUTE_MAXS);
                        reader.accept(new ClassVisitor(Opcodes.ASM9, writer) {
                            @Override public MethodVisitor visitMethod(int access, String method, String desc, String sig, String[] ex) {
                                var target = super.visitMethod(access, method, desc, sig, ex);
                                return new MethodVisitor(Opcodes.ASM9, target) {
                                    void call(String method) { super.visitMethodInsn(Opcodes.INVOKESTATIC, HELPER, method, STRING, false); changed[0] = true; }
                                    boolean matches(String kind, String value) {
                                        String rule = cls + "\t" + method + "\t" + kind + "\t" + Base64.getEncoder().encodeToString(value.getBytes(StandardCharsets.UTF_8));
                                        if (!rules.contains(rule)) return false;
                                        used.add(rule); return true;
                                    }
                                    @Override public void visitCode() {
                                        super.visitCode();
                                        if (cls.equals("qupath/lib/gui/tools/MenuTools") && (method.equals("getMenu") || method.equals("createMenu"))) {
                                            int slot = method.equals("getMenu") ? 1 : 0;
                                            super.visitVarInsn(Opcodes.ALOAD, slot); call("menuPath"); super.visitVarInsn(Opcodes.ASTORE, slot);
                                        }
                                        // String-switch bytecode retains the original hashes and constants.
                                        if (cls.endsWith("PathClassPane$ClassVisibilityConverter") && method.equals("fromString")) {
                                            super.visitVarInsn(Opcodes.ALOAD, 1); call("english"); super.visitVarInsn(Opcodes.ASTORE, 1);
                                        }
                                    }
                                    @Override public void visitInsn(int opcode) {
                                        if (opcode == Opcodes.ARETURN &&
                                            ((cls.endsWith("PathClassPane$PathClassListCell") && method.equals("getText")) ||
                                             (cls.equals("qupath/lib/gui/tools/PathClassListCell") && method.equals("defaultStringFunction")))) call("classLabel");
                                        super.visitInsn(opcode);
                                    }
                                    @Override public void visitLdcInsn(Object value) {
                                        super.visitLdcInsn(value);
                                        if (value instanceof String s && matches("ldc", s)) call("text");
                                    }
                                    @Override public void visitInvokeDynamicInsn(String n, String d, Handle h, Object... constants) {
                                        if (cls.equals("qupath/lib/gui/tools/PathObjectLabels") && desc.startsWith("()") &&
                                            List.of("createListCell", "createTreeCell", "createPane").contains(method)) {
                                            for (int i = 0; i < constants.length; i++) {
                                                if (constants[i] instanceof Handle impl && impl.getOwner().equals("qupath/lib/objects/PathObject") && impl.getName().equals("toString")) {
                                                    constants[i] = new Handle(Opcodes.H_INVOKESTATIC, HELPER, "objectLabel", "(Ljava/lang/Object;)Ljava/lang/String;", false);
                                                    changed[0] = true;
                                                }
                                            }
                                        }
                                        if (h.getOwner().equals("java/lang/invoke/StringConcatFactory") && constants.length > 0 && constants[0] instanceof String s && matches("concat", s)) {
                                            h = new Handle(Opcodes.H_INVOKESTATIC, HELPER, "concat", h.getDesc(), false); changed[0] = true;
                                        }
                                        super.visitInvokeDynamicInsn(n, d, h, constants);
                                    }
                                    @Override public void visitMethodInsn(int op, String owner, String n, String d, boolean itf) {
                                        if (cls.equals("qupath/lib/gui/panes/SelectedMeasurementTableView") && method.equals("tableKeyColumnValueFactory") &&
                                            owner.equals("javafx/beans/property/SimpleStringProperty") && n.equals("<init>") && d.equals("(Ljava/lang/String;)V")) call("text");
                                        if (cls.equals("qupath/lib/gui/panes/SelectedMeasurementTableView$ValueTableCell") && method.equals("updateItem") &&
                                            owner.equals("javafx/scene/control/Label") && n.equals("setText") && d.equals("(Ljava/lang/String;)V")) {
                                            // Slot 3 is the raw row key in the pinned 0.7.0 class.
                                            super.visitVarInsn(Opcodes.ALOAD, 3);
                                            super.visitMethodInsn(Opcodes.INVOKESTATIC, HELPER, "measurementValue", "(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;", false);
                                            changed[0] = true;
                                        }
                                        if (cls.equals("qupath/lib/gui/panes/PathClassPane") && method.equals("createClassPane") &&
                                            owner.equals("qupath/fx/controls/PredicateTextField") && n.equals("<init>") && d.equals("()V")) {
                                            super.visitMethodInsn(op, owner, n, d, itf);
                                            super.visitInsn(Opcodes.DUP);
                                            super.visitMethodInsn(Opcodes.INVOKESTATIC, HELPER, "classFilterFunction", "()Ljava/util/function/Function;", false);
                                            super.visitMethodInsn(Opcodes.INVOKEVIRTUAL, owner, "setStringFunction", "(Ljava/util/function/Function;)V", false);
                                            changed[0] = true; return;
                                        }
                                        if (cls.equals("qupath/lib/gui/panes/SelectedMeasurementTableView") && method.equals("createFilter") &&
                                            owner.equals("qupath/fx/controls/PredicateTextField") && n.equals("<init>") && d.equals("()V")) {
                                            super.visitMethodInsn(op, owner, n, d, itf); super.visitInsn(Opcodes.DUP);
                                            super.visitMethodInsn(Opcodes.INVOKESTATIC, HELPER, "measurementFilterFunction", "()Ljava/util/function/Function;", false);
                                            super.visitMethodInsn(Opcodes.INVOKEVIRTUAL, owner, "setStringFunction", "(Ljava/util/function/Function;)V", false);
                                            changed[0] = true; return;
                                        }
                                        if (owner.equals("java/util/ResourceBundle") && n.equals("getBundle") && d.equals("(Ljava/lang/String;)Ljava/util/ResourceBundle;") &&
                                            (cls.startsWith("qupath/ext/") || cls.startsWith("qupath/fx/"))) {
                                            owner = HELPER; n = "bundle"; changed[0] = true;
                                        }
                                        super.visitMethodInsn(op, owner, n, d, itf);
                                        if (cls.equals("qupath/lib/gui/viewer/ViewerManager") && method.equals("updateSetAnnotationPathClassMenu") &&
                                            owner.equals("qupath/lib/objects/classes/PathClass") && n.equals("toString") && d.equals("()Ljava/lang/String;")) call("classLabel");
                                    }
                                };
                            }
                        }, 0);
                        if (changed[0]) {
                            entries.put(entry.getName(), writer.toByteArray());
                            // Package versions are used by QuPath's extension metadata API.
                            String pkg = cls.substring(0, cls.lastIndexOf('/') + 1);
                            Manifest originalManifest = jar.getManifest();
                            if (originalManifest != null) {
                                Attributes attrs = new Attributes();
                                for (String key : List.of("Implementation-Title", "Implementation-Version", "Implementation-Vendor", "Specification-Title", "Specification-Version", "Specification-Vendor")) {
                                    String value = originalManifest.getMainAttributes().getValue(key);
                                    Attributes packageAttrs = originalManifest.getAttributes(pkg);
                                    if (packageAttrs != null && packageAttrs.getValue(key) != null) value = packageAttrs.getValue(key);
                                    if (value != null) attrs.putValue(key, value);
                                }
                                manifest.getEntries().put(pkg, attrs);
                            }
                            changes.add(jarName + "\t" + cls);
                        }
                    }
                }
            }
            Path helper = Path.of(args[3]);
            for (var path : Files.walk(helper).filter(Files::isRegularFile).toList()) {
                entries.put(helper.relativize(path).toString().replace('\\','/'), Files.readAllBytes(path));
            }
        }
        if (!used.equals(rules)) { rules.removeAll(used); throw new IllegalStateException("Unmatched patch rules: " + rules); }
        try (var out = new JarOutputStream(Files.newOutputStream(output), manifest)) {
            for (var entry : entries.entrySet()) {
                out.putNextEntry(new JarEntry(entry.getKey())); out.write(entry.getValue()); out.closeEntry();
            }
        }
        Files.write(Path.of(output + ".classes.tsv"), changes, StandardCharsets.UTF_8);
        System.out.println("Overlaid classes: " + changes.size() + "; reviewed text sites: " + used.size());
    }
}
