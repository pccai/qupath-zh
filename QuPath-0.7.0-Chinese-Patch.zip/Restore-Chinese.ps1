﻿param(
    [Parameter(Position = 0)][string]$QuPathDirectory,
    [string]$PreferenceNode = 'io.github.qupath/0.7'
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'scripts\Patch.Common.ps1')
try {
    $directory = Resolve-QuPathDirectory $QuPathDirectory
    Assert-QuPathClosed $directory
    $backup = Get-ActivePatchBackup $directory $PreferenceNode
    if (-not $backup) { throw '未找到由本补丁为当前用户创建的有效安装备份。' }
    $restored = @()
    while ($backup) {
        if ($restored -contains $backup) { throw '备份链存在循环，已停止恢复。' }
        $state = Get-Content -LiteralPath (Join-Path $backup 'state.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        Restore-PatchState $state $backup
        $state.Status = 'Restored'
        Save-PatchState $state $backup
        $restored += $backup
        if ($state.PSObject.Properties.Name -contains 'PreviousBackup') { $backup = $state.PreviousBackup }
        else { $backup = $null }
    }
    Write-Host '已恢复安装补丁之前的文件和当前用户界面语言设置。' -ForegroundColor Green
    Write-Host "备份保留于：$backup"
    exit 0
} catch {
    Write-Host "恢复失败：$($_.Exception.Message)" -ForegroundColor Red
    exit 1
}
