﻿param(
    [Parameter(Position = 0)][string]$QuPathDirectory,
    # Advanced: enables integration testing with an isolated Java preference node.
    [string]$PreferenceNode = 'io.github.qupath/0.7'
)
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'scripts\Patch.Common.ps1')
$backupDirectory = $null
$state = $null
$committed = $false
try {
    $directory = Resolve-QuPathDirectory $QuPathDirectory
    Assert-QuPathClosed $directory
    Get-PatchRegistryPath $PreferenceNode | Out-Null
    Write-Host "QuPath 安装目录：$directory"
    $manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($entry in $manifest.files) {
        $path = Join-Path $PSScriptRoot $entry.path
        if ((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ine $entry.sha256) { throw "补丁文件校验失败，请重新解压：$($entry.path)" }
    }
    foreach ($entry in $manifest.requiredJars) {
        $path = Join-Path $directory ('app\' + $entry.name)
        if (-not (Test-Path -LiteralPath $path -PathType Leaf) -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ine $entry.sha256) {
            throw "此安装的程序库与已验证的 QuPath 0.7.0 不同，无法应用界面适配层：$($entry.name)"
        }
    }
    $active = Get-ActivePatchBackup $directory $PreferenceNode
    if ($active) {
        $activeState = Get-Content -LiteralPath (Join-Path $active 'state.json') -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($activeState.PackageVersion -eq $manifest.version) {
            Invoke-PatchHelper $directory $PSScriptRoot 'verify' (Join-Path $active 'verification.json') $PreferenceNode | Out-Null
            Write-Host '中文补丁已安装，校验通过，无需重复安装。' -ForegroundColor Green
            Write-Host "原始备份：$active"
            exit 0
        }
        Write-Host '检测到旧版中文补丁，将保留原始备份并升级。'
    }
    $name = [DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0, 6)
    $backupDirectory = Join-Path $directory ('chinese-patch-backups\' + $name)
    New-Item -ItemType Directory -Path $backupDirectory -Force | Out-Null
    $state = [ordered]@{
        SchemaVersion = 1; PackageVersion = $manifest.version; Status = 'Preparing'; QuPathDirectory = $directory
        UserSID = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value; PreferenceNode = $PreferenceNode
        Preference = Get-LanguagePreference $PreferenceNode; Files = @(); CreatedUtc = [DateTime]::UtcNow.ToString('o')
        PreviousBackup = $active
    }
    Save-PatchState $state $backupDirectory
    $before = Invoke-PatchHelper $directory $PSScriptRoot 'inspect' (Join-Path $backupDirectory 'before.json') $PreferenceNode
    $needModule = -not $before.hasChinese
    if ($needModule -and ($before.javaVendor -ne 'Eclipse Adoptium' -or $before.javaRuntime -notlike '25.0.2+10*')) {
        throw "该运行时没有中文语言数据，且不是本补丁支持的 Eclipse Adoptium 25.0.2+10：$($before.javaVendor) $($before.javaRuntime)"
    }
    $configs = @{}
    foreach ($cfg in @('app\QuPath-0.7.0.cfg', 'app\QuPath-0.7.0 (console).cfg')) {
        $text = [IO.File]::ReadAllText((Join-Path $directory $cfg))
        if ($needModule) { $text = Get-PatchedConfig $text }
        $configs[$cfg] = Get-UIConfig $text
    }
    $copies = @()
    foreach ($entry in $manifest.files) {
        $relative = $entry.path.Substring('payload/'.Length).Replace('/', '\')
        if (-not $needModule -and $relative.StartsWith('app\locale-modules\')) { continue }
        $copies += [pscustomobject]@{ Source = (Join-Path $PSScriptRoot $entry.path); Target = (Join-Path $directory $relative) }
    }
    # A user resource takes precedence over the application's resource. Back it up
    # and update it as well when it already exists, including older Chinese packs.
    if ($before.userResourceFile -and (Test-Path -LiteralPath $before.userResourceFile -PathType Leaf)) {
        $copies += [pscustomobject]@{
            Source = (Join-Path $PSScriptRoot 'payload\app\localization\qupath-gui-strings_zh.properties')
            Target = [string]$before.userResourceFile
        }
    }
    foreach ($license in Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot 'licenses') -File -Recurse) {
        $relative = $license.FullName.Substring((Join-Path $PSScriptRoot 'licenses').Length + 1)
        $copies += [pscustomobject]@{ Source = $license.FullName; Target = (Join-Path $directory ('chinese-patch-licenses\' + $relative)) }
    }
    foreach ($copy in $copies) { Backup-PatchFile $state $backupDirectory $copy.Target }
    foreach ($relative in $configs.Keys) { Backup-PatchFile $state $backupDirectory (Join-Path $directory $relative) }
    $state.Status = 'Applying'
    Save-PatchState $state $backupDirectory
    foreach ($copy in $copies) {
        New-Item -ItemType Directory -Path (Split-Path -Parent $copy.Target) -Force | Out-Null
        Copy-Item -LiteralPath $copy.Source -Destination $copy.Target -Force
    }
    foreach ($relative in $configs.Keys) {
        [IO.File]::WriteAllText((Join-Path $directory $relative), $configs[$relative], [Text.UTF8Encoding]::new($false))
    }
    Set-ChinesePreference $PreferenceNode
    $verified = Invoke-PatchHelper $directory $PSScriptRoot 'verify' (Join-Path $backupDirectory 'verification.json') $PreferenceNode
    if ($verified.result -ne 'PASS') { throw '中文补丁未通过启动校验。' }
    $state.Status = 'Installed'
    Save-PatchState $state $backupDirectory
    $committed = $true
    Write-Host "安装成功：已验证 $($verified.translatedCoreKeys) 项核心翻译、$($verified.supplementalKeys) 项补充词条和 $($verified.extensionKeys) 项组件词条。" -ForegroundColor Green
    Write-Host '现在可正常打开 QuPath，界面语言已设置为中文。'
    Write-Host "备份目录：$backupDirectory"
    exit 0
} catch {
    $reason = $_.Exception.Message
    if ($null -ne $state -and -not $committed) {
        try {
            Restore-PatchState $state $backupDirectory
            $state.Status = 'RolledBack'
            Save-PatchState $state $backupDirectory
            Write-Host '安装未完成，已自动恢复安装前的文件和界面语言。' -ForegroundColor Yellow
        } catch {
            Write-Host "自动恢复遇到错误：$($_.Exception.Message)。备份：$backupDirectory" -ForegroundColor Red
        }
    }
    Write-Host "安装失败：$reason" -ForegroundColor Red
    Write-Host '请确认安装目录正确且可写；系统级安装目录可能需要使用管理员权限。'
    exit 1
}
