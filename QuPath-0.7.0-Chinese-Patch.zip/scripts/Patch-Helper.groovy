import java.util.Locale
import java.util.Properties
import java.nio.charset.StandardCharsets
import java.nio.file.Files
import java.nio.file.Paths
import com.google.gson.GsonBuilder
import qupath.lib.gui.prefs.PathPrefs
import qupath.lib.gui.localization.QuPathResources

def mode = System.getenv('QUPATH_ZH_MODE')
def reportPath = Paths.get(System.getenv('QUPATH_ZH_REPORT'))
def userPath = PathPrefs.userPathProperty().get()
def report = [mode:mode, qupathVersion:System.getProperty('jpackage.app-version'),
    javaVendor:System.getProperty('java.vendor'), javaRuntime:System.getProperty('java.runtime.version'),
    hasChinese:Locale.getAvailableLocales().contains(Locale.CHINESE),
    moduleLoaded:ModuleLayer.boot().findModule('jdk.localedata').isPresent(),
    availableLocales:Locale.getAvailableLocales().length,
    uiLocale:Locale.getDefault(Locale.Category.DISPLAY).toLanguageTag(),
    numberFormat:Locale.getDefault(Locale.Category.FORMAT).toLanguageTag(),
    userResourceFile:userPath == null ? null : Paths.get(userPath,'localization','qupath-gui-strings_zh.properties').toString()]
assert report.qupathVersion == '0.7.0' : 'This patch requires QuPath 0.7.0'
if (mode == 'verify') {
    assert report.hasChinese : 'Chinese locale unavailable'
    assert PathPrefs.defaultLocaleDisplayProperty().get() == Locale.CHINESE : 'Chinese UI preference was not loaded'
    def english = new Properties()
    QuPathResources.class.getResourceAsStream('qupath-gui-strings.properties').withCloseable { stream ->
        new InputStreamReader(stream, StandardCharsets.UTF_8).withCloseable { english.load(it) }
    }
    def chinese = new Properties()
    def source = Paths.get(System.getenv('QUPATH_ZH_APP_DIR'),'localization','qupath-gui-strings_zh.properties')
    Files.newBufferedReader(source, StandardCharsets.UTF_8).withCloseable { chinese.load(it) }
    assert chinese.keySet().containsAll(english.keySet()) : 'Chinese resource lacks core GUI keys'
    english.keySet().each { key -> assert QuPathResources.getString(key) == chinese.getProperty(key) : 'Translation not loaded: ' + key }
    report.translatedCoreKeys = english.size()
    report.menus = ['Menu.File','Menu.Edit','Menu.View','Menu.Help'].collectEntries { [(it):QuPathResources.getString(it)] }
    def ui = Class.forName('qupath.zh.ChineseUI')
    assert ui.text('Annotation list') == '标注列表'
    assert ui.text('No image or object selected') == '尚未选择图像或对象'
    assert ui.classLabel('Tumor (3)') == '肿瘤 (3)'
    assert ui.classLabel('Custom class (3)') == 'Custom class (3)'
    assert qupath.lib.objects.classes.PathClass.getInstance('Tumor').getName() == 'Tumor'
    assert ui.menuPath('Extensions>Deep Java Library') == 'Menu.Extensions>深度学习库（DJL）'
    assert ui.menuPath('Help') == 'Menu.Help'
    def concat = ui.concat(java.lang.invoke.MethodHandles.lookup(), 'makeConcatWithConstants',
        java.lang.invoke.MethodType.methodType(String, Integer.TYPE), 'Annotation list (\u0001)', [] as Object[])
    assert concat.dynamicInvoker().invokeWithArguments(3) == '标注列表（3）'
    def cls = Class.forName('qupath.lib.gui.panes.PathClassPane$ClassVisibilityConverter')
    def ctor = cls.getDeclaredConstructor(); ctor.setAccessible(true)
    def converter = ctor.newInstance()
    def modeClass = Class.forName('qupath.lib.gui.viewer.OverlayOptions$ClassVisibilityMode')
    def toText = cls.getDeclaredMethod('toString', modeClass); toText.setAccessible(true)
    def fromText = cls.getDeclaredMethod('fromString', String); fromText.setAccessible(true)
    modeClass.enumConstants.each { value -> assert fromText.invoke(converter, toText.invoke(converter, value)) == value }
    def supplemental = ResourceBundle.getBundle('qupath-supplemental', Locale.ROOT)
    def supplementalZh = ui.bundle('qupath-supplemental')
    assert supplementalZh.locale.language == 'zh'
    assert supplemental.keySet() == supplementalZh.keySet()
    report.supplementalKeys = supplemental.keySet().size()
    report.extensionKeys = 0
    report.extensionBundles = [:]
    ['qupath.ext.extensionmanager.strings', 'qupath.fx.localization.strings',
     'qupath.ext.djl.ui.strings', 'qupath.ext.training.ui.strings', 'qupath.ext.training.ui.tour'].each { name ->
        def base = ResourceBundle.getBundle(name, Locale.ROOT)
        def translated = ui.bundle(name)
        assert translated.locale.language == 'zh' : 'Component translation not loaded: ' + name
        assert translated.keySet() == base.keySet() : 'Component keys differ: ' + name
        base.keySet().each { key ->
            def placeholders = { s -> (s =~ /\{\d+\}|%(?:\d+\$)?[sdif]/).findAll().sort() }
            assert placeholders(base.getString(key)) == placeholders(translated.getString(key)) : 'Format mismatch: ' + name + ':' + key
        }
        report.extensionBundles[name] = translated.keySet().size()
        report.extensionKeys += translated.keySet().size()
    }
    def manifest = new com.google.gson.Gson().fromJson(
        Files.readString(Paths.get(System.getenv('QUPATH_ZH_MANIFEST')), StandardCharsets.UTF_8), Map)
    manifest.overlayClasses.each { name ->
        def type = Class.forName(name, false, ui.classLoader)
        assert type.protectionDomain.codeSource.location.path.endsWith('/qupath-chinese-ui-0.7.0.jar') : 'Overlay not loaded: ' + name
    }
    report.overlaidClasses = manifest.overlayClasses.size()
    report.classDataPreserved = true
    report.visibilityConverterRoundTrip = true
    assert qupath.ext.djl.DjlExtension.package.implementationVersion == '0.4.2'
    assert qupath.ext.training.ui.TrainingExtension.package.implementationVersion == '0.1.0'
    report.extensionVersionsPreserved = true
    Locale.setDefault(Locale.Category.DISPLAY, Locale.US)
    assert ui.text('Annotation list') == 'Annotation list'
    assert ui.classLabel('Tumor') == 'Tumor'
    assert ui.bundle('qupath.ext.extensionmanager.strings').getString('ExtensionManager.title') == 'Extension Manager'
    Locale.setDefault(Locale.Category.DISPLAY, Locale.CHINESE)
    report.englishFallback = true
    report.result = 'PASS'
}
Files.writeString(reportPath, new GsonBuilder().serializeNulls().setPrettyPrinting().disableHtmlEscaping().create().toJson(report), StandardCharsets.UTF_8)
println 'QUPATH_CHINESE_HELPER_OK=' + mode
