﻿Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Write-PatchJson($Path, $Value) {
    [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 10), [Text.UTF8Encoding]::new($false))
}

function Resolve-QuPathDirectory([string]$Directory) {
    if (-not $Directory) {
        $candidates = @()
        if ($env:LOCALAPPDATA) { $candidates += Join-Path $env:LOCALAPPDATA 'QuPath-0.7.0' }
        foreach ($root in @('HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall', 'HKLM:\Software\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall')) {
            if (-not (Test-Path -LiteralPath $root)) { continue }
            foreach ($key in Get-ChildItem -LiteralPath $root) {
                $name = $key.GetValue('DisplayName')
                if ($name -notlike '*QuPath*0.7.0*') { continue }
                $location = $key.GetValue('InstallLocation')
                if ($location) { $candidates += $location }
                $icon = $key.GetValue('DisplayIcon')
                if ($icon) {
                    $exe = ($icon -replace ',\d+$', '').Trim('"')
                    if (Test-Path -LiteralPath $exe -PathType Leaf) { $candidates += Split-Path -Parent $exe }
                }
            }
        }
        $candidates = @($candidates | Where-Object { Test-Path -LiteralPath (Join-Path $_ 'app\qupath-gui-fx-0.7.0.jar') -PathType Leaf } | Select-Object -Unique)
        if ($candidates.Count -eq 1) { $Directory = $candidates[0] }
        else {
            Add-Type -AssemblyName System.Windows.Forms
            $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
            $dialog.Description = '选择 QuPath 0.7.0 安装文件夹（其中应包含 app、runtime 和 QuPath-0.7.0.exe）'
            $dialog.ShowNewFolderButton = $false
            try {
                if ($dialog.ShowDialog() -ne [Windows.Forms.DialogResult]::OK) { throw '未选择 QuPath 安装目录。' }
                $Directory = $dialog.SelectedPath
            } finally { $dialog.Dispose() }
        }
    }
    if (Test-Path -LiteralPath $Directory -PathType Leaf) { $Directory = Split-Path -Parent $Directory }
    $Directory = [IO.Path]::GetFullPath($Directory).TrimEnd('\')
    foreach ($relative in @('QuPath-0.7.0.exe', 'QuPath-0.7.0 (console).exe', 'app\qupath-gui-fx-0.7.0.jar', 'app\QuPath-0.7.0.cfg', 'app\QuPath-0.7.0 (console).cfg', 'runtime\release')) {
        if (-not (Test-Path -LiteralPath (Join-Path $Directory $relative) -PathType Leaf)) { throw "不是完整的 QuPath 0.7.0 Windows 安装目录，缺少：$relative" }
    }
    return $Directory
}

function Assert-QuPathClosed([string]$Directory) {
    $prefix = $Directory.TrimEnd('\') + '\'
    foreach ($process in Get-CimInstance Win32_Process -Filter "Name = 'QuPath-0.7.0.exe' OR Name = 'QuPath-0.7.0 (console).exe'") {
        if ($process.ExecutablePath -and $process.ExecutablePath.StartsWith($prefix, [StringComparison]::OrdinalIgnoreCase)) {
            throw '请先关闭此安装目录中的 QuPath，再运行补丁。'
        }
    }
}

function Get-PatchRegistryPath([string]$PreferenceNode) {
    if ($PreferenceNode -notmatch '^[a-z0-9._-]+(/[a-z0-9._-]+)*$') { throw '无效的 QuPath 偏好节点。' }
    return 'HKCU:\Software\JavaSoft\Prefs\' + $PreferenceNode.Replace('/', '\')
}

function Get-LanguagePreference([string]$PreferenceNode) {
    $key = Get-Item -LiteralPath (Get-PatchRegistryPath $PreferenceNode) -ErrorAction SilentlyContinue
    $exists = $false
    $value = $null
    if ($key) {
        $exists = @($key.GetValueNames()) -contains 'locale/Display'
        if ($exists) { $value = $key.GetValue('locale/Display') }
    }
    return [pscustomobject]@{ Existed = $exists; Value = $value }
}

function Set-ChinesePreference([string]$PreferenceNode) {
    $path = Get-PatchRegistryPath $PreferenceNode
    if (-not (Test-Path -LiteralPath $path)) { New-Item -Path $path -Force | Out-Null }
    New-ItemProperty -LiteralPath $path -Name 'locale/Display' -Value '/Chinese' -PropertyType String -Force | Out-Null
}

function Invoke-PatchHelper([string]$Directory, [string]$PackageRoot, [string]$Mode, [string]$ReportPath, [string]$PreferenceNode) {
    $names = @('QUPATH_ZH_MODE', 'QUPATH_ZH_REPORT', 'QUPATH_ZH_APP_DIR', 'QUPATH_ZH_MANIFEST')
    $before = @{}
    foreach ($name in $names) { $before[$name] = [Environment]::GetEnvironmentVariable($name, 'Process') }
    try {
        $env:QUPATH_ZH_MODE = $Mode
        $env:QUPATH_ZH_REPORT = $ReportPath
        $env:QUPATH_ZH_APP_DIR = Join-Path $Directory 'app'
        $env:QUPATH_ZH_MANIFEST = Join-Path $PackageRoot 'manifest.json'
        $exe = Join-Path $Directory 'QuPath-0.7.0 (console).exe'
        $helper = Join-Path $PackageRoot 'scripts\Patch-Helper.groovy'
        # Windows PowerShell 5.1 turns routine native stderr warnings into ErrorRecords.
        $ErrorActionPreference = 'Continue'
        $output = @(& $exe "-Dqupath.prefs.name=$PreferenceNode" script $helper 2>&1)
        $nativeExit = $LASTEXITCODE
        $ErrorActionPreference = 'Stop'
        [IO.File]::WriteAllLines(($ReportPath + '.log'), [string[]]@($output | ForEach-Object { $_.ToString() }), [Text.UTF8Encoding]::new($false))
        if ($nativeExit -ne 0) { throw "QuPath 校验失败。日志：$ReportPath.log" }
        if (-not (Test-Path -LiteralPath $ReportPath -PathType Leaf)) { throw "QuPath 未生成校验报告：$ReportPath" }
        return Get-Content -LiteralPath $ReportPath -Raw -Encoding UTF8 | ConvertFrom-Json
    } finally {
        foreach ($name in $names) { [Environment]::SetEnvironmentVariable($name, $before[$name], 'Process') }
    }
}

function Save-PatchState($State, [string]$BackupDirectory) {
    Write-PatchJson (Join-Path $BackupDirectory 'state.json') $State
}

function Backup-PatchFile($State, [string]$BackupDirectory, [string]$Target) {
    if (@($State.Files | Where-Object { $_.Target -eq $Target }).Count -gt 0) { return }
    $relative = 'files\' + ('{0:D3}.bin' -f @($State.Files).Count)
    $existed = Test-Path -LiteralPath $Target -PathType Leaf
    if ((Test-Path -LiteralPath $Target) -and -not $existed) { throw "目标不是普通文件：$Target" }
    if ($existed) {
        New-Item -ItemType Directory -Path (Join-Path $BackupDirectory 'files') -Force | Out-Null
        Copy-Item -LiteralPath $Target -Destination (Join-Path $BackupDirectory $relative)
    }
    $State.Files += [pscustomobject]@{ Target = $Target; Existed = $existed; Backup = $relative }
    Save-PatchState $State $BackupDirectory
}

function Restore-PatchState($State, [string]$BackupDirectory) {
    foreach ($file in $State.Files) {
        if ($file.Existed) {
            $parent = Split-Path -Parent $file.Target
            New-Item -ItemType Directory -Path $parent -Force | Out-Null
            Copy-Item -LiteralPath (Join-Path $BackupDirectory $file.Backup) -Destination $file.Target -Force
        } elseif (Test-Path -LiteralPath $file.Target -PathType Leaf) {
            Remove-Item -LiteralPath $file.Target -Force
        }
    }
    $path = Get-PatchRegistryPath $State.PreferenceNode
    if ($State.Preference.Existed) {
        if (-not (Test-Path -LiteralPath $path)) { New-Item -Path $path -Force | Out-Null }
        New-ItemProperty -LiteralPath $path -Name 'locale/Display' -Value ([string]$State.Preference.Value) -PropertyType String -Force | Out-Null
    } elseif (Test-Path -LiteralPath $path) {
        Remove-ItemProperty -LiteralPath $path -Name 'locale/Display' -ErrorAction SilentlyContinue
    }
}

function Get-ActivePatchBackup([string]$Directory, [string]$PreferenceNode) {
    $root = Join-Path $Directory 'chinese-patch-backups'
    if (-not (Test-Path -LiteralPath $root)) { return $null }
    $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    foreach ($backup in Get-ChildItem -LiteralPath $root -Directory | Sort-Object Name -Descending) {
        $path = Join-Path $backup.FullName 'state.json'
        if (-not (Test-Path -LiteralPath $path)) { continue }
        $state = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($state.Status -eq 'Installed' -and $state.UserSID -eq $sid -and $state.PreferenceNode -eq $PreferenceNode) { return $backup.FullName }
    }
    return $null
}

function Get-PatchedConfig([string]$Text) {
    if ($Text -notmatch '(?m)^\[JavaOptions\]\s*$') { throw '启动配置缺少 [JavaOptions] 段。' }
    $modulePaths = @([regex]::Matches($Text, '(?m)^java-options=(?:--module-path|-p)(?:=.*|\s*)$'))
    foreach ($match in $modulePaths) {
        if ($match.Value.TrimEnd("`r") -ne 'java-options=--module-path=$APPDIR\locale-modules') {
            throw '此安装使用了自定义 Java 模块路径，补丁未修改它。请先在副本上评估兼容性。'
        }
    }
    $add = @()
    if ($modulePaths.Count -eq 0) { $add += 'java-options=--module-path=$APPDIR\locale-modules' }
    if ($Text -notmatch '(?m)^java-options=--add-modules=jdk\.localedata\s*$') { $add += 'java-options=--add-modules=jdk.localedata' }
    if ($add.Count -eq 0) { return $Text }
    $newline = "`n"
    if ($Text.Contains("`r`n")) { $newline = "`r`n" }
    $block = $newline + ($add -join $newline) + $newline
    # Insert inside JavaOptions even if another section follows it.
    $section = [regex]::Match($Text, '(?ms)^\[JavaOptions\][^\r\n]*\r?\n.*?(?=^\[|\z)')
    if (-not $section.Success) { throw '无法解析 [JavaOptions] 段。' }
    return $Text.Insert($section.Index + $section.Length, $block)
}

function Get-UIConfig([string]$Text) {
    if ($Text -notmatch '(?m)^\[Application\]\s*$') { throw '启动配置缺少 [Application] 段。' }
    $newline = "`n"
    if ($Text.Contains("`r`n")) { $newline = "`r`n" }
    # The overlay must precede the original JARs; they remain byte-for-byte intact.
    $lines = @('app.classpath=$APPDIR\localization', 'app.classpath=$APPDIR\qupath-chinese-ui-0.7.0.jar')
    foreach ($line in $lines) {
        $Text = [regex]::Replace($Text, '(?m)^' + [regex]::Escape($line) + '\r?\n?', '')
    }
    $section = [regex]::Match($Text, '(?m)^\[Application\][^\r\n]*\r?\n')
    return $Text.Insert($section.Index + $section.Length, ($lines -join $newline) + $newline)
}
